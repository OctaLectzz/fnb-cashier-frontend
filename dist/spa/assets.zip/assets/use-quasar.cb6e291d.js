import{i as a,b6 as r}from"./index.199a5e3f.js";function u(){return a(r)}export{u};
