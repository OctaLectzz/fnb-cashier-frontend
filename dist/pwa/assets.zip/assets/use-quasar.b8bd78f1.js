import{i as a,bg as r}from"./index.c5c224d7.js";function u(){return a(r)}export{u};
