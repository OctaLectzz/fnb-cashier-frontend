import{i as a,bg as r}from"./index.4b455d6d.js";function u(){return a(r)}export{u};
